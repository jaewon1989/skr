<?php
if(!defined('__KIMS__')) exit;
if($my['uid']) exit;
$targetModule = 'slogin';
include $g['path_module'].$targetModule.'/var/var.php';
include $g['path_module'].$targetModule.'/action/a.slogin.php';
$g['snskor'] = array(
	'f' => array('페이스북','facebook',1000,650,'#39589C'),
   	'k' => array('카카오톡','kakao',400,450,'#EBBA0F'),
	'n' => array('네이버','naver',400,450,'#23C10A'),
	'g' => array('구글','google',450,450,'#D94C35'),
	't' => array('트위터','twitter',810,550,'#1DA1F2'),
	'i' => array('인스타그램','instagram',500,350,'#3D6B92'),
);
$sns_f = $sns_k = $sns_n = $sns_g = $sns_t = $sns_i = '';

//임시
if (is_array($_SESSION['SL']['naver']) || is_array($_SESSION['SL']['kakao']) || is_array($_SESSION['SL']['facebook']) || is_array($_SESSION['SL']['google']) || is_array($_SESSION['SL']['instagram']) || is_array($_SESSION['SL']['twitter']))
{
	$name		= '';
	$nic		= '';
	$email		= '';
	$id			= 'sns'.$g['time_split'][1].substr($g['time_split'][0],2,6);
	$pw			= $id;

	if (is_array($_SESSION['SL']['naver']))
	{
		$snsuid	= $_SESSION['SL']['naver']['userinfo']['birthday'].$_SESSION['SL']['naver']['userinfo']['sex'].$_SESSION['SL']['naver']['userinfo']['age'];
		$sns_n = $snsuid;
		$name	= $_SESSION['SL']['naver']['userinfo']['name'];
		$nic	= $name;
		$email	= $_SESSION['SL']['naver']['userinfo']['email'];
		$sex	= $_SESSION['SL']['naver']['userinfo']['sex'];
		$birth2	= $_SESSION['SL']['naver']['userinfo']['birthday'];
		$_photo	= $_SESSION['SL']['naver']['userinfo']['photo'];
		$rute 	= 'naver';
	}
	if (is_array($_SESSION['SL']['kakao']))
	{
		$snsuid	= $_SESSION['SL']['kakao']['userinfo']['uid'];
		$sns_k = $snsuid;
		$name	= $_SESSION['SL']['kakao']['userinfo']['name'];
		$nic	= $name;
		$birth2	= $_SESSION['SL']['kakao']['userinfo']['birthday'];
		$birthtype	= $_SESSION['SL']['kakao']['userinfo']['birthday_type'];
		$home	= $_SESSION['SL']['kakao']['userinfo']['link'];
		$_photo	= $_SESSION['SL']['kakao']['userinfo']['photo'];
		$rute 	= 'kakao';
	}
	if (is_array($_SESSION['SL']['facebook']))
	{
		$snsuid	= $_SESSION['SL']['facebook']['userinfo']['uid'];
		$sns_f	= $snsuid;
		$name	= $_SESSION['SL']['facebook']['userinfo']['name'];
		$nic	= $name;
		$email	= $_SESSION['SL']['facebook']['userinfo']['email'];
		$sex	= $_SESSION['SL']['facebook']['userinfo']['sex'];
		$birth1	= substr($_SESSION['SL']['facebook']['userinfo']['birthday'],0,4);
		$birth2	= substr($_SESSION['SL']['facebook']['userinfo']['birthday'],6,2).substr($_SESSION['SL']['facebook']['userinfo']['birthday'],4,2);
		$home	= $_SESSION['SL']['facebook']['userinfo']['link'];
		$_photo	= $_SESSION['SL']['facebook']['userinfo']['photo'];
		$rute 	= 'facebook';
	}
	if (is_array($_SESSION['SL']['google']))
	{
		$snsuid	= $_SESSION['SL']['google']['userinfo']['uid'];
		$sns_g 	= $snsuid;
		$name	= $_SESSION['SL']['google']['userinfo']['name'];
		$nic	= $name;
		$email	= $_SESSION['SL']['google']['userinfo']['email'];
		$sex	= $_SESSION['SL']['google']['userinfo']['sex'];
		$home	= $_SESSION['SL']['google']['userinfo']['link'];
		$_photo	= $_SESSION['SL']['naver']['userinfo']['photo'];
		$rute 	= 'google+';
	}
	if (is_array($_SESSION['SL']['instagram']))
	{
		$snsuid	= $_SESSION['SL']['instagram']['userinfo']['uid'];
		$sns_i 	= $snsuid;
		$name	= $_SESSION['SL']['instagram']['userinfo']['name'];
		$nic	= $name;
		$home	= $_SESSION['SL']['instagram']['userinfo']['link'];
		$_photo	= $_SESSION['SL']['instagram']['userinfo']['photo'];
		$rute 	= 'instagram';
	}
	if (is_array($_SESSION['SL']['twitter']))
	{
		$snsuid	= $_SESSION['SL']['twitter']['userinfo']['uid'];
		$sns_t 	= $snsuid;
		$name	= $_SESSION['SL']['twitter']['userinfo']['name'];
		$nic	= $name;
		$home	= $_SESSION['SL']['twitter']['userinfo']['link'];
		$_photo	= $_SESSION['SL']['twitter']['userinfo']['photo'];
		$rute 	= 'twitter';
	}
	//결과값 못 받은 경우
	if (!$name)
	{
		$_SESSION['SL'] = '';
		if($_isModal) getLink('reload','','','');
		else getLink('reload','','','');
	}
	//소셜 로그인 중복체크
	$_isSNSlogin = db_query("SELECT member_seq FROM fm_membersns where sns_f='".$snsuid."' limit 1;",$DB_CONNECT);
	$isSNSlogin = db_fetch_assoc($_isSNSlogin);
	//getLink('','','테스트중 : '.$isSNSlogin['member_seq'],'');
	if ($isSNSlogin['member_seq'])
	{


	$_FM = db_query("select A.*,B.business_seq,B.bname,C.group_name from fm_member A LEFT JOIN fm_member_business B ON A.member_seq = B.member_seq left join fm_member_group C on C.group_seq=A.group_seq where A.member_seq=".$isSNSlogin['member_seq'],$DB_CONNECT);
	$FM = db_fetch_assoc($_FM);

	$_SESSION['user'] = array('member_seq' => $FM['member_seq']    ,'userid' => $FM['userid']    ,'user_name' => $FM['user_name']    ,'birthday' => ''    ,'sex' => $FM['sex']   ,'group_seq' => $FM['group_seq']    ,'group_name' => $FM['group_name']    ,'rute' => $FM['rute']    ,'gnb_icon_view' => ''    ,'password_update_date' => $FM['password_update_date']    ,'coupon_birthday_count' => ''    ,'coupon_anniversary_count' => ''    ,'coupon_membergroup_count' => '');
		getLink('/','_top','SNS로그인 완료','');
		//else getLink('reload','','','');
	}
	// //중복 이메일이 존재할 경우
	// $isMember = getDbData($table['s_mbrdata'],"email='".$email."'",'memberuid');
	// if ($isMember['memberuid'])
	// {
	// 	$M	= getUidData($table['s_mbrid'],$isMember['memberuid']); 
	// 	$_SESSION['mbr_uid'] = $M['member_seq'];
	// 	$_SESSION['mbr_pw']  = $M['password'];
	// 	$_SESSION['SL'] = '';
	// 	if($_isModal) getLink('reload','','','');
	// 	else getLink('reload','','','');
	// }
	$_pw = hash('sha256',md5($pw));
	getDbInsert($table['s_mbrid'],'site,id,pw',"'$s','$id','".$_pw."'");
	//include $g['path_core'].'function/rss.func.php';
	//$_photodata = getUrlData($_photo,10);
	
	if ($_photo && strpos($_photo,'facebook'))
	{
		$_facebookHeaders = get_headers($_photo, 1);
		if (array_key_exists('Location', $_facebookHeaders))
		{
			$_photo = $_facebookHeaders['Location'];
			$_photodata = getCURLData($_photo,'');
		}
	}
	else {
		$_photodata = getCURLData($_photo,'');
	}
	
	if ($_photodata)
	{
		$fileExt	= 'jpg';
		$fp = fopen($g['path_var'].'avatar/snstmp.jpg','w');
		fwrite($fp,$_photodata);
		fclose($fp);
		$photo		= $id.'.'.$fileExt;
		$saveFile1	= $g['path_var'].'avatar/'.$photo;
		$saveFile2	= $g['path_var'].'avatar/180.'.$photo;
		include $g['path_core'].'function/thumb.func.php';
		ResizeWidth($g['path_var'].'avatar/snstmp.jpg',$saveFile2,180);
		ResizeWidthHeight($saveFile2,$saveFile1,50,50);
		@chmod($saveFile1,0707);
		@chmod($saveFile2,0707);
		unlink($g['path_var'].'avatar/snstmp.jpg');
	}

	//필요부분
	$nowtime = date('Y-m-d H:i:s', time());
	$join_point = 0; // 가입시 지급 포인트

	$_QKEY = "group_seq,group_set_date,userid,password,user_name,nickname,rute,email,mailing,phone,cellphone,sms,";

	$_QKEY.= "zipcode,address_type,address,address_street,address_detail,sex,birth_type,birthday,anniversary,recommend,status,";
	$_QKEY.= "emoney,emoney_limitDate,login_cnt,review_cnt,order_cnt,order_sum,lastlogin_date,regist_date,update_date,grade_update_date,";
	$_QKEY.= "admin_memo,admin_log,login_addr,auth_type,auth_code,sns_f,sns_t,sns_m,sns_y,recommend_send,fb_invite,marketplace,";
	
	$_QKEY.= "sns_c,sns_g,sns_p,sns_n,sns_k,sns_d,point,point_limitDate,cash,member_order_cnt,member_order_price,member_recommend_cnt,";
	$_QKEY.= "member_invite_cnt,auth_vno,referer,referer_domain,platform,member_order_goods_cnt,user_icon,user_icon_file,password_update_date,";
	$_QKEY.= "bank_name,bank_no,bank_master";

// 이메일 암호화 예정
	$_QVAL = "'1','0000-00-00 00:00:00','$snsuid','30A507A408D625FEA14651C1C4E2C123','$name','$nic','$rute',(HEX(AES_ENCRYPT('".$email."', 'ODg4Nzg='))),'n',NULL,NULL,'n',";
	$_QVAL.= "NULL,NULL,NULL,NULL,NULL,'none','none','0000-00-00','',NULL,'done',";
	$_QVAL.= "0,NULL,1,0,0,0,'$nowtime','$nowtime','$nowtime','0000-00-00 00:00:00',";
	$_QVAL.= "NULL,NULL,'".$_SERVER['REMOTE_ADDR']."','none',NULL,'$sns_f','$sns_t','$sns_m','$sns_y',NULL,NULL,'',";
	$_QVAL.= "'$sns_c','$sns_g','$sns_p','$sns_n','$sns_k','$sns_d',$join_point,NULL,0,0,0,0,";
	$_QVAL.= "0,'',0,0,'P',0,1,'',NULL,";
	$_QVAL.= "'','',''";


	getDbInsert('fm_member',$_QKEY,$_QVAL);
	$memberuid  = mysql_insert_id();

	$_QKEY= "seq,member_seq,sns_f,user_name,email,sex,birthday,rute";
	$_QVAL= "NULL,'$memberuid','$snsuid','$name','','none','0000-00-00','$rute'";
	getDbInsert('fm_membersns',$_QKEY,$_QVAL);

	$_SESSION['user'] = array('member_seq' => $memberuid ,'userid' => $snsuid  ,'user_name' => $name    ,'birthday' => ''    ,'sex' => 'none'   ,'group_seq' => '1'    ,'group_name' => '일반'    ,'rute' => $rute    ,'gnb_icon_view' => ''    ,'password_update_date' => $FM['password_update_date']    ,'coupon_birthday_count' => ''    ,'coupon_anniversary_count' => ''    ,'coupon_membergroup_count' => '');


	if($_isModal) getLink('reload','','','');
	else getLink('reload','','','');
}
$slogin['naver'] = socialLogin('naver',$d['slogin']['key_n'],$d['slogin']['secret_n'],$g['url_root'].'/?r='.$r.'&m='.$targetModule.'&a=slogin&sloginReturn=naver',false);
$slogin['kakao'] = socialLogin('kakao',$d['slogin']['key_k'],$d['slogin']['secret_k'],$g['url_root'].'/?r='.$r.'&m='.$targetModule.'&a=slogin&sloginReturn=kakao',false);
$slogin['facebook'] = socialLogin('facebook',$d['slogin']['key_f'],$d['slogin']['secret_f'],$g['url_root'].'/?r='.$r.'&m='.$targetModule.'&a=slogin&sloginReturn=facebook',false);
$slogin['google'] = socialLogin('google',$d['slogin']['key_g'],$d['slogin']['secret_g'],$g['url_root'].'/?r='.$r.'&m='.$targetModule.'&a=slogin&sloginReturn=google',false);
$slogin['instagram'] = socialLogin('instagram',$d['slogin']['key_i'],$d['slogin']['secret_i'],$g['url_root'].'/?r='.$r.'&m='.$targetModule.'&a=slogin&sloginReturn=instagram',false);
$slogin['twitter'] = socialLogin('twitter',$d['slogin']['key_t'],$d['slogin']['secret_t'],$g['url_root'].'/?r='.$r.'&m='.$targetModule.'&a=slogin&sloginReturn=twitter',false);
?>